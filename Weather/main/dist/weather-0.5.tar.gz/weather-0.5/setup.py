from setuptools import setup
setup(
    name="weather",
    version="0.5",
    description="main application package",
    author="Juan Garcia Lugo",
    url="https://github.com/JuanLugoN/Modelado_Y_Programacion/tree/master/Weather",
    packages=['weather','weather.database','weather.webservice']
)