from weather.database.AirportDatabaseReader import extractCities
from weather.database.AirportDatabaseReader import readDatabase
from weather.webservice.OpenWeather import verifyCity
import threading

if __name__ == '__main__':
	data = "../../data/dataset.csv"
	weatherOfLocations = set()
	extractCities(readDatabase(data),weatherOfLocations)
	for city in weatherOfLocations:
		thread = threading.Thread(target=verifyCity,args=(city,))
		thread.start()