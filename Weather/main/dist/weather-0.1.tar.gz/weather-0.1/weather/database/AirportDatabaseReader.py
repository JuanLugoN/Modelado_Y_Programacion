def readDatabase(path):
	try:
		database = open(path)
		cities = database.read().splitlines()[1:]
		database.close()
		return cities
	except:
		cities = []
		return cities
	
def extractCities(database,cities):
	for row in database:
		parameters = row.split(",")
		cities.add((parameters[0],parameters[2],parameters[3]))
		cities.add((parameters[1],parameters[4],parameters[5]))