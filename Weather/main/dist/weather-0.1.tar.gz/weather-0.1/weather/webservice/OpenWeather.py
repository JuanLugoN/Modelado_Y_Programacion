import requests
from requests.exceptions import ConnectionError

def verifyCity(city):
	url = "http://api.openweathermap.org/data/2.5/weather?lat={}&lon={}&uk&APPID=9ee969687e25812a1e19a77054ab4003&units=metric".format(city[1], city[2])
	try:
		reponse = requests.get(url)
		weather = reponse.json()["main"]
		location = "Ciudad: {}, lat: {}, lon: {} \n".format(city[0],city[1],city[2])
		location += "Temperatura: {}\n".format(weather["temp"])
		location += "Presión: {}\n".format(weather["pressure"])
		location += "humedad: {}\n".format(weather["humidity"])
	except KeyError:
		location = "Ciudad: {}, lat: {}, lon: {} \n".format(city[0],city[1],city[2])
		location += "Temperatura: Error en coordenas"
		location += "Presión: Error en coordenas"
		location += "humedad: Error en coordenas"
	except ConnectionError:
		location = "Ciudad: {}, lat: {}, lon: {} \n".format(city[0],city[1],city[2])
		location += "Temperatura: Error en conexion\n"
		location += "Presión: Error en conexion\n"
		location += "humedad: Error en conexion\n"
	except:
		location = "Ciudad: {}, lat: {}, lon: {} \n".format(city[0],city[1],city[2])
		location += "Temperatura: Error webservice\n"
		location += "Presión: Error webservice\n"
		location += "humedad: Error webservice\n"
	finally:
		print(location)